import React from 'react';
import { useNavigate } from 'react-router-dom';


const OpeningPage = () => {

  const navigate1=useNavigate()
  
  
  return (
    <div>
        
    </div>
  );
};

export default OpeningPage;
